"""Food Ordering & Delivery - Flask front end.  All business rules live in MySQL (triggers/procedures)."""
import pymysql
from functools import wraps
from flask import Flask, g, render_template, request, redirect, url_for, session, flash, abort
from config import DB, DB_NAME, SECRET_KEY, ADMIN_PASSWORD
from reports import REPORTS

app = Flask(__name__)
app.secret_key = SECRET_KEY

@app.template_filter("inr")
def inr(v): return "\u20b9{:,.2f}".format(float(v or 0))
@app.template_filter("dt")
def dt(v): return v.strftime("%d %b, %I:%M %p") if v else "-"
@app.template_filter("pretty")
def pretty(v): return str(v).replace("_", " ").title()

# ---------------------------------------------------------------- database helpers
def get_db():
    if "db" not in g:
        g.db = pymysql.connect(**DB, database=DB_NAME, autocommit=False, cursorclass=pymysql.cursors.DictCursor)
    return g.db

@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        if exc: db.rollback()
        db.close()

def query(sql, args=(), one=False):
    cur = get_db().cursor()
    cur.execute(sql, args)
    rows = cur.fetchall()
    return (rows[0] if rows else None) if one else rows

def db_error(e):
    """Turns a MySQL error raised by SIGNAL / CHECK / FK into a readable message."""
    msg = e.args[1] if len(e.args) > 1 else str(e)
    if "chk_" in msg: msg = "Value rejected by a database CHECK constraint: " + msg
    return msg

def customer_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("customer_id"):
            flash("Please choose who you are first.", "info"); return redirect(url_for("login", next=request.path))
        return f(*a, **k)
    return w

def admin_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("admin"): return redirect(url_for("admin_login"))
        return f(*a, **k)
    return w

@app.context_processor
def inject():
    cart = session.get("cart") or {}
    me = None
    if session.get("customer_id"):
        me = query("SELECT customer_id, name FROM customers WHERE customer_id=%s", (session["customer_id"],), one=True)
    return dict(me=me, cart_count=sum((cart.get("items") or {}).values()), is_admin=session.get("admin"))

# ---------------------------------------------------------------- customer side
@app.route("/")
def home():
    stats = query("""SELECT (SELECT COUNT(*) FROM restaurants WHERE is_open) AS open_restaurants,
                            (SELECT COUNT(*) FROM menu_items WHERE available) AS dishes,
                            (SELECT COUNT(*) FROM orders WHERE status='delivered') AS delivered,
                            (SELECT COUNT(*) FROM delivery_partners WHERE status='available') AS free_partners""", one=True)
    top = query("SELECT * FROM v_restaurant_stats WHERE review_count > 0 ORDER BY avg_rating DESC, review_count DESC LIMIT 4")
    popular = query("SELECT item, restaurant, units_sold FROM v_item_sales ORDER BY units_sold DESC LIMIT 6")
    coupons = query("SELECT code, discount_pct, max_discount, min_order FROM coupons WHERE is_active AND valid_till >= CURDATE()")
    return render_template("home.html", stats=stats, top=top, popular=popular, coupons=coupons)

@app.route("/restaurants")
def restaurants():
    cuisine = request.args.get("cuisine", ""); term = request.args.get("q", "").strip()
    sql = "SELECT * FROM restaurants WHERE 1=1"; args = []
    if cuisine: sql += " AND cuisine=%s"; args.append(cuisine)
    if term: sql += " AND name LIKE %s"; args.append(f"%{term}%")
    rows = query(sql + " ORDER BY is_open DESC, avg_rating DESC, name", args)
    cuisines = [r["cuisine"] for r in query("SELECT DISTINCT cuisine FROM restaurants ORDER BY cuisine")]
    return render_template("restaurants.html", rows=rows, cuisines=cuisines, cuisine=cuisine, q=term)

@app.route("/restaurant/<int:rid>")
def restaurant(rid):
    r = query("SELECT * FROM restaurants WHERE restaurant_id=%s", (rid,), one=True) or abort(404)
    veg = request.args.get("veg") == "1"
    items = query("""SELECT mi.*, c.name AS category FROM menu_items mi JOIN categories c USING(category_id)
                     WHERE mi.restaurant_id=%s """ + ("AND mi.is_veg " if veg else "") + "ORDER BY c.category_id, mi.name", (rid,))
    menu = {}
    for it in items: menu.setdefault(it["category"], []).append(it)
    reviews = query("""SELECT v.rating, v.comment, v.created_at, c.name FROM reviews v JOIN customers c USING(customer_id)
                       WHERE v.restaurant_id=%s ORDER BY v.created_at DESC LIMIT 5""", (rid,))
    return render_template("restaurant.html", r=r, menu=menu, reviews=reviews, veg=veg)

@app.post("/cart/add")
def cart_add():
    item_id = int(request.form["item_id"]); qty = max(1, min(20, int(request.form.get("qty", 1))))
    it = query("SELECT item_id, restaurant_id, available FROM menu_items WHERE item_id=%s", (item_id,), one=True) or abort(404)
    if not it["available"]:
        flash("That item is currently unavailable.", "error"); return redirect(request.referrer or url_for("restaurants"))
    cart = session.get("cart") or {"restaurant_id": it["restaurant_id"], "items": {}}
    if cart["restaurant_id"] != it["restaurant_id"]:
        cart = {"restaurant_id": it["restaurant_id"], "items": {}}
        flash("Your cart had items from another restaurant, so it was reset.", "info")
    cart["items"][str(item_id)] = min(20, cart["items"].get(str(item_id), 0) + qty)
    session["cart"] = cart
    flash("Added to cart.", "ok")
    return redirect(request.referrer or url_for("cart"))

@app.post("/cart/update")
def cart_update():
    cart = session.get("cart")
    if cart:
        for k, v in request.form.items():
            if k.startswith("q_"):
                n = int(v or 0); iid = k[2:]
                if n <= 0: cart["items"].pop(iid, None)
                else: cart["items"][iid] = min(n, 20)
        if not cart["items"]: session.pop("cart")
        else: session["cart"] = cart
    return redirect(url_for("cart"))

def cart_lines():
    cart = session.get("cart")
    if not cart or not cart["items"]: return None, [], 0
    ids = list(map(int, cart["items"]))
    rows = query(f"SELECT item_id, name, price, is_veg FROM menu_items WHERE item_id IN ({','.join(['%s']*len(ids))})", ids)
    lines = [dict(r, qty=cart["items"][str(r["item_id"])], line=r["price"] * cart["items"][str(r["item_id"])]) for r in rows]
    rest = query("SELECT * FROM restaurants WHERE restaurant_id=%s", (cart["restaurant_id"],), one=True)
    return rest, lines, sum(l["line"] for l in lines)

@app.route("/cart")
def cart():
    rest, lines, subtotal = cart_lines()
    addresses = query("SELECT * FROM addresses WHERE customer_id=%s ORDER BY is_default DESC", (session.get("customer_id"),)) if session.get("customer_id") else []
    coupons = query("SELECT code, discount_pct, max_discount, min_order FROM coupons WHERE is_active AND valid_till >= CURDATE()")
    return render_template("cart.html", rest=rest, lines=lines, subtotal=subtotal, addresses=addresses, coupons=coupons)

@app.post("/checkout")
@customer_required
def checkout():
    cart = session.get("cart")
    if not cart or not cart["items"]:
        flash("Your cart is empty.", "error"); return redirect(url_for("restaurants"))
    db = get_db(); cur = db.cursor()
    try:   # ONE transaction: either the whole order is created, or nothing is (atomicity)
        cur.execute("CALL sp_place_order(%s,%s,%s,%s,@oid)", (session["customer_id"], cart["restaurant_id"],
                    int(request.form["address_id"]), request.form.get("coupon", "").strip() or None))
        cur.execute("SELECT @oid AS oid"); oid = cur.fetchone()["oid"]
        for iid, qty in cart["items"].items():
            cur.execute("CALL sp_add_item(%s,%s,%s)", (oid, int(iid), qty))
        cur.execute("CALL sp_checkout(%s,%s)", (oid, request.form["method"]))
        db.commit()
    except pymysql.err.MySQLError as e:
        db.rollback(); flash("Order not placed: " + db_error(e), "error"); return redirect(url_for("cart"))
    session.pop("cart", None)
    flash(f"Order #{oid} placed successfully!", "ok")
    return redirect(url_for("order_detail", oid=oid))

@app.route("/orders")
@customer_required
def my_orders():
    rows = query("SELECT * FROM v_order_summary WHERE customer_id=%s ORDER BY order_time DESC", (session["customer_id"],))
    return render_template("orders.html", rows=rows)

@app.route("/order/<int:oid>")
@customer_required
def order_detail(oid):
    o = query("""SELECT o.*, r.name AS restaurant, dp.name AS partner, dp.phone AS partner_phone, a.line1, a.city, a.pincode,
                        p.method, p.status AS pay_status, cp.code AS coupon
                 FROM orders o JOIN restaurants r USING(restaurant_id) JOIN addresses a USING(address_id)
                 LEFT JOIN delivery_partners dp ON dp.partner_id=o.partner_id
                 LEFT JOIN payments p ON p.order_id=o.order_id LEFT JOIN coupons cp ON cp.coupon_id=o.coupon_id
                 WHERE o.order_id=%s AND o.customer_id=%s""", (oid, session["customer_id"]), one=True) or abort(404)
    items = query("SELECT mi.name, oi.quantity, oi.unit_price, oi.quantity*oi.unit_price AS line FROM order_items oi JOIN menu_items mi USING(item_id) WHERE oi.order_id=%s", (oid,))
    log = query("SELECT new_status, changed_at FROM order_status_log WHERE order_id=%s ORDER BY log_id", (oid,))
    review = query("SELECT * FROM reviews WHERE order_id=%s", (oid,), one=True)
    return render_template("order.html", o=o, items=items, log=log, review=review)

@app.post("/order/<int:oid>/cancel")
@customer_required
def cancel_order(oid):
    if not query("SELECT 1 FROM orders WHERE order_id=%s AND customer_id=%s", (oid, session["customer_id"])): abort(404)
    db = get_db()
    try:
        db.cursor().execute("CALL sp_update_status(%s,'cancelled')", (oid,)); db.commit(); flash("Order cancelled. Paid amounts are refunded automatically.", "ok")
    except pymysql.err.MySQLError as e:
        db.rollback(); flash("Cannot cancel: " + db_error(e), "error")
    return redirect(url_for("order_detail", oid=oid))

@app.post("/order/<int:oid>/review")
@customer_required
def review(oid):
    db = get_db()
    try:
        db.cursor().execute("INSERT INTO reviews (order_id, customer_id, restaurant_id, rating, comment) VALUES (%s,%s,0,%s,%s)",
                            (oid, session["customer_id"], int(request.form["rating"]), request.form.get("comment", "")[:300] or None))
        db.commit(); flash("Thanks for your review!", "ok")
    except pymysql.err.MySQLError as e:
        db.rollback(); flash("Review not saved: " + db_error(e), "error")
    return redirect(url_for("order_detail", oid=oid))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        c = query("SELECT customer_id FROM customers WHERE customer_id=%s", (request.form["customer_id"],), one=True)
        if c: session["customer_id"] = c["customer_id"]; return redirect(request.args.get("next") or url_for("restaurants"))
    return render_template("login.html", customers=query("SELECT customer_id, name, email FROM customers ORDER BY name"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        db = get_db(); cur = db.cursor(); f = request.form
        try:
            cur.execute("INSERT INTO customers (name,email,phone) VALUES (%s,%s,%s)", (f["name"].strip(), f["email"].strip().lower(), f["phone"].strip()))
            cid = cur.lastrowid
            cur.execute("INSERT INTO addresses (customer_id,label,line1,city,pincode,is_default) VALUES (%s,'Home',%s,%s,%s,1)",
                        (cid, f["line1"].strip(), f["city"].strip(), f["pincode"].strip()))
            db.commit(); session["customer_id"] = cid; flash("Welcome aboard!", "ok"); return redirect(url_for("restaurants"))
        except pymysql.err.MySQLError as e:
            db.rollback(); flash("Could not register: " + ("email or phone already used" if e.args[0] == 1062 else db_error(e)), "error")
    return render_template("register.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("home"))

# ---------------------------------------------------------------- reports (public, for the demo)
@app.route("/reports")
def reports():
    results = []
    for title, desc, sql in REPORTS:
        cur = get_db().cursor(); cur.execute(sql); rows = cur.fetchall()
        results.append(dict(title=title, desc=desc, sql=sql, rows=rows, cols=list(rows[0].keys()) if rows else []))
    return render_template("reports.html", results=results)

# ---------------------------------------------------------------- admin
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        if request.form["password"] == ADMIN_PASSWORD: session["admin"] = True; return redirect(url_for("admin"))
        flash("Wrong password.", "error")
    return render_template("admin_login.html")

@app.route("/admin")
@admin_required
def admin():
    kpi = query("""SELECT (SELECT COUNT(*) FROM orders) orders, (SELECT COALESCE(SUM(total),0) FROM orders WHERE status='delivered') revenue,
                          (SELECT COUNT(*) FROM orders WHERE status IN ('placed','preparing','out_for_delivery')) active,
                          (SELECT COUNT(*) FROM customers) customers""", one=True)
    pipeline = query("SELECT status, COUNT(*) n FROM orders GROUP BY status")
    active = query("SELECT * FROM v_order_summary WHERE status IN ('placed','preparing','out_for_delivery') ORDER BY order_time")
    partners = query("SELECT * FROM v_partner_performance ORDER BY deliveries DESC")
    return render_template("admin.html", kpi=kpi, pipeline=pipeline, active=active, partners=partners)

NEXT = {"placed": "preparing", "preparing": "out_for_delivery", "out_for_delivery": "delivered"}
@app.post("/admin/order/<int:oid>/<action>")
@admin_required
def admin_order(oid, action):
    o = query("SELECT status FROM orders WHERE order_id=%s", (oid,), one=True) or abort(404)
    new = "cancelled" if action == "cancel" else NEXT.get(o["status"])
    db = get_db()
    try:
        db.cursor().execute("CALL sp_update_status(%s,%s)", (oid, new)); db.commit(); flash(f"Order #{oid} is now {new.replace('_',' ')}.", "ok")
    except (pymysql.err.MySQLError, TypeError) as e:
        db.rollback(); flash("Update failed: " + (db_error(e) if isinstance(e, pymysql.err.MySQLError) else "no further step"), "error")
    return redirect(url_for("admin"))

@app.route("/admin/catalog")
@admin_required
def admin_catalog():
    rests = query("SELECT * FROM restaurants ORDER BY name")
    items = query("SELECT mi.*, r.name AS restaurant FROM menu_items mi JOIN restaurants r USING(restaurant_id) ORDER BY r.name, mi.name")
    return render_template("admin_catalog.html", rests=rests, items=items)

@app.post("/admin/toggle/<kind>/<int:xid>")
@admin_required
def admin_toggle(kind, xid):
    db = get_db()
    if kind == "restaurant": db.cursor().execute("UPDATE restaurants SET is_open = NOT is_open WHERE restaurant_id=%s", (xid,))
    elif kind == "item": db.cursor().execute("UPDATE menu_items SET available = NOT available WHERE item_id=%s", (xid,))
    else: abort(404)
    db.commit(); return redirect(url_for("admin_catalog"))

if __name__ == "__main__":
    app.run(debug=True, port=5000)
