"""Analytical SQL queries shown on the Reports page and exported to sql/06_reports.sql."""
REPORTS = [
 ("Top 5 restaurants by revenue",
  "View + ORDER BY/LIMIT. v_restaurant_stats already joins restaurants with their delivered orders.",
  """SELECT name, cuisine, orders_delivered, revenue, avg_order_value, avg_rating
FROM v_restaurant_stats
ORDER BY revenue DESC
LIMIT 5;"""),
 ("Daily revenue with 7-day moving average (last 14 days)",
  "Window function: AVG() OVER a sliding frame of 7 rows.",
  """SELECT day, orders, revenue,
       ROUND(AVG(revenue) OVER (ORDER BY day ROWS BETWEEN 6 PRECEDING AND CURRENT ROW), 2) AS moving_avg_7d
FROM v_daily_revenue
WHERE day >= CURDATE() - INTERVAL 14 DAY
ORDER BY day DESC;"""),
 ("Best-selling item of every restaurant",
  "RANK() OVER (PARTITION BY ...) inside a derived table, then filter rank = 1.",
  """SELECT restaurant, item, units_sold, item_revenue FROM (
    SELECT restaurant, item, units_sold, item_revenue,
           RANK() OVER (PARTITION BY restaurant_id ORDER BY units_sold DESC) AS rnk
    FROM v_item_sales
) t
WHERE rnk = 1 AND units_sold > 0
ORDER BY units_sold DESC;"""),
 ("Customers who spent more than the average customer",
  "Scalar subquery in HAVING-style filter over the v_customer_value view.",
  """SELECT name, orders, lifetime_spend, tier
FROM v_customer_value
WHERE lifetime_spend > (SELECT AVG(lifetime_spend) FROM v_customer_value WHERE orders > 0)
ORDER BY lifetime_spend DESC
LIMIT 10;"""),
 ("Menu items that were never ordered",
  "LEFT JOIN ... IS NULL (anti-join) to find dead stock on the menu.",
  """SELECT r.name AS restaurant, mi.name AS item, mi.price
FROM menu_items mi
JOIN restaurants r ON r.restaurant_id = mi.restaurant_id
LEFT JOIN order_items oi ON oi.item_id = mi.item_id
WHERE oi.item_id IS NULL
ORDER BY r.name, mi.name;"""),
 ("Payment method share",
  "GROUP BY with a window SUM() OVER () to turn counts into percentages.",
  """SELECT method, COUNT(*) AS payments, SUM(amount) AS amount,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct_of_orders
FROM payments
GROUP BY method
ORDER BY payments DESC;"""),
 ("Peak ordering hours",
  "Date function HOUR() with GROUP BY; shows when to schedule more delivery partners.",
  """SELECT HOUR(order_time) AS hour_of_day, COUNT(*) AS orders, ROUND(SUM(total), 2) AS revenue
FROM orders
WHERE status <> 'cancelled'
GROUP BY HOUR(order_time)
ORDER BY orders DESC
LIMIT 8;"""),
 ("Repeat-customer rate",
  "Common Table Expression (CTE) counting orders per customer, then aggregating the result.",
  """WITH per_customer AS (
    SELECT customer_id, COUNT(*) AS n FROM orders WHERE status = 'delivered' GROUP BY customer_id
)
SELECT COUNT(*) AS customers_who_ordered,
       SUM(n > 1) AS repeat_customers,
       ROUND(100 * SUM(n > 1) / COUNT(*), 1) AS repeat_rate_pct
FROM per_customer;"""),
 ("Well-rated restaurants (above overall average, min 3 reviews)",
  "HAVING + subquery comparing each group with the global average.",
  """SELECT r.name, ROUND(AVG(v.rating), 2) AS avg_rating, COUNT(*) AS reviews
FROM reviews v
JOIN restaurants r ON r.restaurant_id = v.restaurant_id
GROUP BY r.restaurant_id, r.name
HAVING COUNT(*) >= 3 AND AVG(v.rating) > (SELECT AVG(rating) FROM reviews)
ORDER BY avg_rating DESC;"""),
 ("Delivery partner performance",
  "View v_partner_performance: deliveries and average delivery time in minutes.",
  """SELECT name, status, deliveries, avg_minutes
FROM v_partner_performance
ORDER BY deliveries DESC;"""),
 ("Index in action: EXPLAIN for 'recent orders of a customer'",
  "EXPLAIN shows MySQL uses idx_orders_customer_time (customer_id, order_time) instead of scanning the table.",
  """EXPLAIN SELECT order_id, order_time, total
FROM orders
WHERE customer_id = 3
ORDER BY order_time DESC;"""),
]
if __name__ == "__main__":
    out = ["-- =====================================================================",
           "--  06_reports.sql : analytical queries (joins, views, window functions, CTE, subqueries)",
           "-- =====================================================================", "USE food_delivery;", ""]
    for i, (t, d, s) in enumerate(REPORTS, 1):
        out += [f"-- {i}. {t}", f"-- {d}", s, ""]
    open("sql/06_reports.sql", "w").write("\n".join(out))
    print("written sql/06_reports.sql")
