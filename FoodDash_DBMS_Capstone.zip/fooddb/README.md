# 🍽️ FoodDash: Online Food Ordering & Delivery DBMS

DBMS capstone: a MySQL database that enforces food-delivery business rules itself (triggers, stored procedures, constraints, transactions), plus a Flask web app on top.

![ER](docs/er_diagram.png)

## Quick start

1. Install **MySQL 8+** and **Python 3.10+**.
2. Install packages: `pip install -r requirements.txt`
3. Set your MySQL login if it is not `root` with an empty password:
   - Windows PowerShell: `$env:DB_USER="root"; $env:DB_PASSWORD="yourpassword"`
   - Mac/Linux: `export DB_USER=root DB_PASSWORD=yourpassword`
4. Build the database (schema, procedures, triggers, views, sample data, ~140 sample orders):
   `python setup_db.py`
5. Run the app: `python app.py`, then open http://localhost:5000
   - Customer: click **Login** and pick any sample customer (no password).
   - Admin: http://localhost:5000/admin, password `admin123`.

Prefer the MySQL command line? Run the files in `sql/` in order (`mysql -u root -p < sql/01_schema.sql` and so on). `setup_db.py` also creates the sample orders.

## Tests
```
python tests/test_db.py     # 31 checks: every trigger, procedure, constraint and rule violation
python tests/test_app.py    # 29 checks: full web flow (login, cart, checkout, admin, review, cancel)
```
`tests/test_app.py` places real orders, so run `python setup_db.py` again afterwards for a clean demo database.

## Project structure
```
sql/01_schema.sql                 tables, keys, CHECK constraints, indexes
sql/02_functions_procedures.sql   fn_calc_discount, sp_place_order, sp_add_item, sp_checkout, sp_assign_partner, sp_update_status, sp_recalc_order
sql/03_triggers.sql               12 triggers (validation, totals, status rules, audit, ratings)
sql/04_views.sql                  6 views for dashboard and reports
sql/05_seed.sql                   master data (customers, restaurants, menu, partners, coupons)
sql/06_reports.sql                11 analytical queries (also shown on the Reports page)
setup_db.py                       builds everything + generates demo orders through the procedures
app.py, reports.py, config.py     Flask app, report definitions, settings
templates/, static/               HTML (Jinja) and CSS
docs/                             ER diagram, screenshots, PROJECT_DETAILS.md
tests/                            database and web tests
```

## Design highlights
**Schema (3NF, 12 tables):** customers, addresses, restaurants, categories, menu_items, delivery_partners, coupons, orders, order_items, payments, reviews, order_status_log. `order_items` resolves the many-to-many between orders and menu items and stores the **price at order time**, so later menu price changes never alter old orders.

**Normalisation:** every non-key attribute depends on the key, the whole key and nothing but the key. Customer and address data are separate; categories are separate from items; order totals are derived values kept in sync by triggers. `restaurants.avg_rating` and `review_count` are a deliberate, trigger-maintained denormalisation so the home page does not aggregate all reviews on every request.

**Rules enforced by the database (the app cannot bypass them):**
| Rule | Where |
|---|---|
| Item must be available and belong to the order's restaurant; price frozen at order time | trigger `trg_oi_before_insert` |
| Subtotal, discount, delivery fee (free above ₹499, else ₹40) and total always correct | `sp_recalc_order` called by order_items triggers |
| Coupon valid, active, not expired; discount capped, minimum order respected | `sp_place_order`, `fn_calc_discount` |
| Only legal status moves: placed, preparing, out for delivery, delivered; cancel only before dispatch | trigger `trg_orders_before_update` |
| Partner auto-assigned, set busy on dispatch, freed on delivery | `sp_assign_partner` + trigger `trg_orders_after_update` |
| COD becomes paid on delivery; cancelling a paid order refunds it | trigger `trg_orders_after_update` |
| Payment amount must equal order total | trigger `trg_pay_before_insert` |
| Only the customer who got a delivered order can review it, once | trigger `trg_rev_before_insert` + UNIQUE(order_id) |
| Restaurant rating kept current | triggers on reviews |
| Every status change recorded | `order_status_log` via trigger |
| Valid phone, email, pincode, price > 0, quantity 1-20, rating 1-5 | CHECK constraints |

**Transactions (ACID):** checkout runs `sp_place_order`, several `sp_add_item` calls and `sp_checkout` in one transaction. If any step fails (bad coupon, unavailable item), everything rolls back and no half-created order remains (proved in `tests/test_app.py`).

**Concurrency:** `sp_assign_partner` uses `SELECT ... FOR UPDATE SKIP LOCKED`, so two simultaneous dispatches cannot grab the same delivery partner.

**Indexes:** composite `orders(customer_id, order_time)` serves "my recent orders"; the Reports page runs `EXPLAIN` to show it being used.

## Likely viva questions
- *Why a trigger instead of checking in Flask?* Rules in the database apply to every client (app, script, another tool); the application cannot forget them.
- *Why store `unit_price` in order_items?* Historical orders must keep the price the customer paid.
- *Why is there a derived `total` column? Is that redundant?* Yes, deliberately: it is maintained by triggers, never by the app, and tested for consistency.
- *What stops two orders taking the same partner?* Row locking with `FOR UPDATE SKIP LOCKED`.
- *What is atomicity here?* Checkout is one transaction; a failure rolls everything back.

## Notes
- Demo login has no password so examiners can try any customer; add real authentication (hashed passwords) for production.
- Change `SECRET_KEY` and `ADMIN_PASSWORD` (see `.env.example`) before deploying anywhere public.
