# Capstone Project Details (copy into the submission link)

**Project title:** FoodDash: Online Food Ordering & Delivery Management System

**Team (max 2 students):**
1. [Student 1 name, roll no.]
2. [Student 2 name, roll no.]

**Domain:** Database Management System (DBMS), Food-tech / e-commerce

**Problem statement:** Local food ordering needs many linked records (customers, restaurants, menus, orders, payments, delivery partners, reviews) to stay consistent at all times. Spreadsheet or file-based systems allow duplicate orders, wrong prices, double-booked delivery partners and mismatched payments. This project builds a relational database that enforces these rules itself, with a working web application on top.

**Objectives**
1. Design a normalised (3NF) relational schema with 12 tables, keys and constraints.
2. Move business rules into the database using triggers, stored procedures and a function.
3. Guarantee consistency with transactions (an order is created completely or not at all).
4. Provide views and analytical SQL (joins, window functions, CTE, subqueries) for management reports.
5. Deliver a working model: customer ordering flow, admin operations and a reports page.

**Modules**
- Customer: register/login, browse restaurants, veg filter, cart, coupons, checkout (UPI/Card/Wallet/COD), order tracking, cancellation with automatic refund, reviews.
- Restaurant & menu management: open/closed toggle, item availability.
- Order processing: status workflow (placed, preparing, out for delivery, delivered, cancelled) with automatic delivery-partner assignment.
- Payments: payment record per order, COD settled on delivery, refund on cancellation.
- Reports: top restaurants, moving-average revenue, best sellers, peak hours, repeat-customer rate, payment mix, partner performance, EXPLAIN of an index.

**DBMS concepts demonstrated**
ER modelling, 1:1 / 1:N / M:N (order_items) relationships, primary/foreign/unique keys, CHECK and ENUM constraints, normalisation (1NF to 3NF), controlled denormalisation (restaurant rating), 12 triggers, 6 stored procedures, 1 function, 6 views, composite indexes and EXPLAIN, transactions and atomicity (ACID), row locking with FOR UPDATE SKIP LOCKED, window functions, CTE, subqueries, audit logging.

**Technology stack:** MySQL 8+ (database), Python 3 + Flask (backend), HTML/CSS with Jinja templates (frontend), PyMySQL (driver).

**Working model:** runs locally at http://localhost:5000 after `python setup_db.py` and `python app.py`. Sample data: 30 customers, 10 restaurants, 80 dishes, 8 delivery partners, 5 coupons and about 140 generated orders with payments and reviews.
