import os
DB = dict(
    host=os.getenv("DB_HOST", "127.0.0.1"),
    port=int(os.getenv("DB_PORT", "3306")),
    user=os.getenv("DB_USER", "root"),
    password=os.getenv("DB_PASSWORD", ""),
)
DB_NAME = os.getenv("DB_NAME", "food_delivery")
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-in-production")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")
