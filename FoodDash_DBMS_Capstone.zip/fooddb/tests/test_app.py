"""Web-app flow test (Flask test client against the real database).  Run: python tests/test_app.py"""
import os, re, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import app as A
c = A.app.test_client(); n = 0
def ok(name, cond):
    global n; assert cond, "FAILED: " + name; n += 1; print("  ok -", name)
def text(r): return r.get_data(as_text=True)
def db(sql, a=()):
    with A.app.app_context():
        return A.query(sql, a)

before = db("SELECT MAX(order_id) m FROM orders")[0]["m"]
ok("cart works without login", c.post("/cart/add", data={"item_id": 1, "qty": 2}, follow_redirects=True).status_code == 200)
r = c.post("/checkout", data={"address_id": 1, "method": "UPI"}, follow_redirects=True)
ok("checkout without login redirects to login", "Please choose who you are" in text(r))
c.post("/login", data={"customer_id": 1})
c.post("/cart/add", data={"item_id": 2, "qty": 1}); c.post("/cart/add", data={"item_id": 3, "qty": 2})
r = c.get("/cart"); ok("cart page lists items and subtotal", "Dal Makhani" in text(r) and "Subtotal" in text(r))
addr = db("SELECT address_id FROM addresses WHERE customer_id=1 LIMIT 1")[0]["address_id"]
r = c.post("/checkout", data={"address_id": addr, "method": "UPI", "coupon": "BADCODE"}, follow_redirects=True)
ok("invalid coupon is rejected by the database and shown to the user", "Invalid or expired coupon" in text(r))
ok("failed checkout left no partial order behind (atomicity)", db("SELECT MAX(order_id) m FROM orders")[0]["m"] == before)
r = c.post("/checkout", data={"address_id": addr, "method": "UPI", "coupon": "FEAST15"}, follow_redirects=True)
oid = int(re.search(r"Order #(\d+)", text(r)).group(1))
ok("order placed, detail page shows totals", "Order #%d" % oid in text(r) and "Placed" in text(r))
o = db("SELECT * FROM orders WHERE order_id=%s", (oid,))[0]
ok("discount and total computed by the database", o["discount"] > 0 and o["total"] == o["subtotal"] - o["discount"] + o["delivery_fee"])
ok("payment recorded as paid (UPI)", db("SELECT status s FROM payments WHERE order_id=%s", (oid,))[0]["s"] == "paid")
ok("customer cannot see another customer's order", A.app.test_client().get("/order/%d" % oid).status_code == 302)
c2 = A.app.test_client(); c2.post("/login", data={"customer_id": 2})
ok("another customer gets 404 for this order", c2.get("/order/%d" % oid).status_code == 404)

ca = A.app.test_client()
ok("admin page needs password", ca.get("/admin").status_code == 302)
ok("wrong admin password rejected", "Wrong password" in text(ca.post("/admin/login", data={"password": "x"})))
ca.post("/admin/login", data={"password": A.ADMIN_PASSWORD})
ok("admin sees the active order", "#%d" % oid in text(ca.get("/admin")))
for expect in ["preparing", "out for delivery", "delivered"]:
    r = ca.post("/admin/order/%d/next" % oid, follow_redirects=True); ok("admin moves order to " + expect, "is now " + expect in text(r))
ok("partner assigned automatically", db("SELECT partner_id FROM orders WHERE order_id=%s", (oid,))[0]["partner_id"] is not None)
r = c.get("/order/%d" % oid); ok("tracking timeline shows Delivered", "Delivered" in text(r) and "Your review" in text(r))
r = c.post("/order/%d/review" % oid, data={"rating": 5, "comment": "great"}, follow_redirects=True); ok("review saved", "Thanks for your review" in text(r))
r = c.post("/order/%d/review" % oid, data={"rating": 4}, follow_redirects=True); ok("second review blocked by UNIQUE constraint", "Review not saved" in text(r))
r = c.post("/order/%d/cancel" % oid, follow_redirects=True); ok("delivered order cannot be cancelled", "Cannot cancel" in text(r) and "Illegal order status transition" in text(r))

c.post("/cart/add", data={"item_id": 1, "qty": 1})
r = c.post("/checkout", data={"address_id": addr, "method": "COD"}, follow_redirects=True); oid2 = int(re.search(r"Order #(\d+)", text(r)).group(1))
r = c.post("/order/%d/cancel" % oid2, follow_redirects=True); ok("customer can cancel a new order", "Order cancelled" in text(r))
ok("cancelled COD order payment marked failed", db("SELECT status s FROM payments WHERE order_id=%s", (oid2,))[0]["s"] == "failed")
c.post("/cart/add", data={"item_id": 1, "qty": 1})
r = c.post("/cart/add", data={"item_id": 20, "qty": 1}, follow_redirects=True)
ok("adding from another restaurant resets the cart", "cart had items from another restaurant" in text(r))
mail = "test.user.%d@example.com" % oid
form = {"name": "Test User", "email": mail, "phone": "9%09d" % oid, "line1": "1 Test Rd", "city": "Gurugram", "pincode": "122001"}
ok("new customer can register", "Welcome aboard" in text(A.app.test_client().post("/register", data=form, follow_redirects=True)))
ok("duplicate email rejected by UNIQUE constraint", "email or phone already used" in text(A.app.test_client().post("/register", data=form, follow_redirects=True)))
r = A.app.test_client().post("/register", data={"name": "Bad", "email": "bad@example.com", "phone": "12345", "line1": "x", "city": "g", "pincode": "1"}, follow_redirects=True)
ok("bad phone rejected by CHECK constraint", "Could not register" in text(r))
r = ca.get("/reports"); ok("reports page runs all 11 queries", text(r).count("<h3>") >= 11 and "Top 5 restaurants" in text(r))
r = ca.get("/reports"); ok("EXPLAIN report proves the index is used", "idx_orders_customer_time" in text(r))
r = ca.post("/admin/toggle/item/1"); ca.post("/admin/toggle/item/1")
print(f"\n{n} checks passed")
