"""Database tests: proves every trigger / procedure rule.  Run: python tests/test_db.py"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pymysql
from config import DB, DB_NAME

con = pymysql.connect(**DB, database=DB_NAME, autocommit=False, cursorclass=pymysql.cursors.DictCursor)
cur = con.cursor()
passed = 0
def q1(sql, a=()):
    cur.execute(sql, a); return cur.fetchone()
def expect_error(fragment, fn):
    global passed
    cur.execute("SAVEPOINT t")
    try:
        fn()
    except pymysql.err.MySQLError as e:
        assert fragment.lower() in str(e).lower(), f"expected '{fragment}' but got: {e}"
        cur.execute("ROLLBACK TO SAVEPOINT t"); passed += 1; return
    raise AssertionError(f"no error raised, expected '{fragment}'")
def ok(name, cond):
    global passed
    assert cond, "FAILED: " + name
    passed += 1; print("  ok -", name)

cust = q1("SELECT customer_id FROM customers ORDER BY customer_id LIMIT 1")["customer_id"]
addr = q1("SELECT address_id FROM addresses WHERE customer_id=%s LIMIT 1", (cust,))["address_id"]
other_addr = q1("SELECT address_id FROM addresses WHERE customer_id<>%s LIMIT 1", (cust,))["address_id"]
rest = q1("SELECT restaurant_id FROM restaurants WHERE name='Spice Route Kitchen'")["restaurant_id"]
cur.execute("SELECT item_id FROM menu_items WHERE restaurant_id=%s ORDER BY item_id", (rest,))
items = [r["item_id"] for r in cur.fetchall()]
other_item = q1("SELECT item_id FROM menu_items WHERE restaurant_id<>%s LIMIT 1", (rest,))["item_id"]

def place(code=None):
    cur.execute("CALL sp_place_order(%s,%s,%s,%s,@o)", (cust, rest, addr, code)); return q1("SELECT @o o")["o"]

print("Procedures, functions and triggers")
oid = place()
cur.execute("CALL sp_add_item(%s,%s,1)", (oid, items[0])); cur.execute("CALL sp_add_item(%s,%s,1)", (oid, items[1]))
o = q1("SELECT * FROM orders WHERE order_id=%s", (oid,))
price0 = q1("SELECT price FROM menu_items WHERE item_id=%s", (items[0],))["price"]
price1 = q1("SELECT price FROM menu_items WHERE item_id=%s", (items[1],))["price"]
ok("subtotal = sum(qty x price) maintained by triggers", o["subtotal"] == price0 + price1)
ok("delivery fee Rs 40 below Rs 499, total correct", o["delivery_fee"] == 40 and o["total"] == o["subtotal"] + 40)
cur.execute("CALL sp_add_item(%s,%s,1)", (oid, items[0]))
ok("adding same item again increases quantity (upsert)", q1("SELECT quantity q FROM order_items WHERE order_id=%s AND item_id=%s", (oid, items[0]))["q"] == 2)
cur.execute("UPDATE menu_items SET price = price + 100 WHERE item_id=%s", (items[0],))
ok("price frozen at order time (menu price change does not alter old order)",
   q1("SELECT unit_price u FROM order_items WHERE order_id=%s AND item_id=%s", (oid, items[0]))["u"] == price0)
con.rollback()

oid = place("FEAST15")
for it in items[:4]: cur.execute("CALL sp_add_item(%s,%s,2)", (oid, it))
o = q1("SELECT * FROM orders WHERE order_id=%s", (oid,))
ok("coupon FEAST15: 15% off capped at Rs 150; free delivery over Rs 499",
   o["discount"] == min(round(float(o["subtotal"])*0.15, 2), 150) and o["delivery_fee"] == 0 and o["total"] == o["subtotal"] - o["discount"])
ok("fn_calc_discount works as a function", float(q1("SELECT fn_calc_discount(1000, (SELECT coupon_id FROM coupons WHERE code='FEAST15')) d")["d"]) == 150)

expect_error("different restaurant", lambda: (cur.execute("CALL sp_place_order(%s,%s,%s,NULL,@o)", (cust, rest, addr)),
                                               cur.execute("CALL sp_add_item(%s,%s,1)", (q1("SELECT @o o")["o"], other_item))))
expect_error("does not belong", lambda: cur.execute("CALL sp_place_order(%s,%s,%s,NULL,@o)", (cust, rest, other_addr)))
expect_error("expired coupon", lambda: cur.execute("CALL sp_place_order(%s,%s,%s,'OLD10',@o)", (cust, rest, addr)))
expect_error("unavailable", lambda: (cur.execute("UPDATE menu_items SET available=FALSE WHERE item_id=%s", (items[2],)),
                                     cur.execute("CALL sp_place_order(%s,%s,%s,NULL,@o)", (cust, rest, addr)),
                                     cur.execute("CALL sp_add_item(%s,%s,1)", (q1("SELECT @o o")["o"], items[2]))))
expect_error("closed", lambda: (cur.execute("UPDATE restaurants SET is_open=FALSE WHERE restaurant_id=%s", (rest,)),
                                cur.execute("CALL sp_place_order(%s,%s,%s,NULL,@o)", (cust, rest, addr))))
expect_error("chk_qty", lambda: (cur.execute("CALL sp_place_order(%s,%s,%s,NULL,@o)", (cust, rest, addr)),
                                  cur.execute("CALL sp_add_item(%s,%s,50)", (q1("SELECT @o o")["o"], items[0]))))
expect_error("empty order", lambda: (cur.execute("CALL sp_place_order(%s,%s,%s,NULL,@o)", (cust, rest, addr)),
                                     cur.execute("CALL sp_checkout(%s,'UPI')", (q1("SELECT @o o")["o"],))))
print("  ok - 7 rule violations are rejected (wrong restaurant, wrong address, expired coupon, unavailable item, closed restaurant, bad quantity, empty checkout)")

# life cycle
oid = place()
cur.execute("CALL sp_add_item(%s,%s,1)", (oid, items[0])); cur.execute("CALL sp_checkout(%s,'COD')", (oid,))
ok("COD payment starts pending", q1("SELECT status s FROM payments WHERE order_id=%s", (oid,))["s"] == "pending")
expect_error("Illegal order status", lambda: cur.execute("CALL sp_update_status(%s,'delivered')", (oid,)))
cur.execute("CALL sp_update_status(%s,'preparing')", (oid,)); cur.execute("CALL sp_update_status(%s,'out_for_delivery')", (oid,))
p = q1("SELECT o.partner_id, dp.status s FROM orders o JOIN delivery_partners dp USING(partner_id) WHERE order_id=%s", (oid,))
ok("partner auto-assigned and marked busy on dispatch", p["partner_id"] is not None and p["s"] == "busy")
cur.execute("CALL sp_update_status(%s,'delivered')", (oid,))
ok("delivery frees the partner", q1("SELECT status s FROM delivery_partners WHERE partner_id=%s", (p["partner_id"],))["s"] == "available")
ok("COD payment becomes paid on delivery", q1("SELECT status s FROM payments WHERE order_id=%s", (oid,))["s"] == "paid")
ok("every status change was audited (4 log rows)", q1("SELECT COUNT(*) c FROM order_status_log WHERE order_id=%s", (oid,))["c"] == 4)
expect_error("Illegal order status", lambda: cur.execute("CALL sp_update_status(%s,'cancelled')", (oid,)))

# reviews
cur.execute("SELECT avg_rating, review_count FROM restaurants WHERE restaurant_id=%s", (rest,)); before = cur.fetchone()
cur.execute("INSERT INTO reviews (order_id, customer_id, restaurant_id, rating) VALUES (%s,%s,%s,5)", (oid, cust, 0))
after = q1("SELECT avg_rating, review_count FROM restaurants WHERE restaurant_id=%s", (rest,))
ok("review trigger fills restaurant_id and updates average rating/count", after["review_count"] == before["review_count"] + 1)
expect_error("Duplicate", lambda: cur.execute("INSERT INTO reviews (order_id, customer_id, restaurant_id, rating) VALUES (%s,%s,%s,4)", (oid, cust, 0)))
oid2 = place(); cur.execute("CALL sp_add_item(%s,%s,1)", (oid2, items[0]))
expect_error("Only delivered", lambda: cur.execute("INSERT INTO reviews (order_id, customer_id, restaurant_id, rating) VALUES (%s,%s,%s,4)", (oid2, cust, 0)))
con.rollback()

# cancellation refund
oid = place(); cur.execute("CALL sp_add_item(%s,%s,1)", (oid, items[0])); cur.execute("CALL sp_checkout(%s,'UPI')", (oid,))
cur.execute("CALL sp_update_status(%s,'cancelled')", (oid,))
ok("cancelling a paid order refunds the payment", q1("SELECT status s FROM payments WHERE order_id=%s", (oid,))["s"] == "refunded")
expect_error("does not match", lambda: (cur.execute("CALL sp_place_order(%s,%s,%s,NULL,@o)", (cust, rest, addr)),
     cur.execute("CALL sp_add_item(%s,%s,1)", (q1("SELECT @o o")["o"], items[0])),
     cur.execute("INSERT INTO payments (order_id,method,status,amount) VALUES (%s,'UPI','paid',1)", (q1("SELECT @o o")["o"],))))
con.rollback()

print("Constraints and views")
expect_error("check constraint", lambda: cur.execute("INSERT INTO customers (name,email,phone) VALUES ('x','x@y.com','12345')"))
expect_error("check constraint", lambda: cur.execute("UPDATE menu_items SET price=0 WHERE item_id=%s", (items[0],)))
expect_error("Duplicate", lambda: cur.execute("INSERT INTO customers (name,email,phone) SELECT 'dup', email, '9999999999' FROM customers LIMIT 1"))
ok("views return rows", all(q1(f"SELECT COUNT(*) c FROM {v}")["c"] > 0 for v in
   ["v_order_summary", "v_restaurant_stats", "v_item_sales", "v_partner_performance", "v_customer_value", "v_daily_revenue"]))
ok("sample data volume", q1("SELECT COUNT(*) c FROM orders")["c"] >= 140 and q1("SELECT COUNT(*) c FROM order_items")["c"] > 250)
ok("data integrity: stored totals equal recomputed totals for all orders",
   q1("""SELECT COUNT(*) c FROM orders o JOIN (SELECT order_id, SUM(quantity*unit_price) s FROM order_items GROUP BY order_id) x USING(order_id)
         WHERE o.subtotal <> x.s""")["c"] == 0)
print(f"\n{passed} checks passed")
