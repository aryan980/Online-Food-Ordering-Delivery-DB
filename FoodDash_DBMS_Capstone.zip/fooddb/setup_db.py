"""
Builds the whole database:  python setup_db.py
 1. runs sql/01..05 (schema, procedures, triggers, views, master data)
 2. generates ~140 historical orders THROUGH the stored procedures, so every trigger
    (price freezing, totals, status audit, partner availability, ratings) really runs.
Use --no-orders to skip step 2.
"""
import os, random, sys
from datetime import datetime, timedelta
import pymysql
from config import DB, DB_NAME

SQL_DIR = os.path.join(os.path.dirname(__file__), "sql")
FILES = ["01_schema.sql", "02_functions_procedures.sql", "03_triggers.sql", "04_views.sql", "05_seed.sql"]

def run_script(cur, path):
    """Executes a .sql file; understands the mysql-client 'DELIMITER' command."""
    delim, buf, n = ";", [], 0
    for line in open(path, encoding="utf-8"):
        if line.strip().upper().startswith("DELIMITER "):
            delim = line.strip().split(None, 1)[1]
            continue
        buf.append(line)
        if "".join(buf).rstrip().endswith(delim):
            stmt = "".join(buf).rstrip()[: -len(delim)].strip()
            buf = []
            body = "\n".join(l for l in stmt.splitlines() if not l.strip().startswith("--")).strip()
            if body:
                cur.execute(stmt); n += 1
    return n

def build_schema():
    con = pymysql.connect(**DB, autocommit=True)
    cur = con.cursor()
    for f in FILES:
        print(f"  running {f}: {run_script(cur, os.path.join(SQL_DIR, f))} statements")
    con.close()

def generate_orders(n_orders=140, seed=11):
    random.seed(seed)
    con = pymysql.connect(**DB, database=DB_NAME, autocommit=False, cursorclass=pymysql.cursors.DictCursor)
    cur = con.cursor()
    cur.execute("SELECT customer_id FROM customers"); customers = [r["customer_id"] for r in cur.fetchall()]
    cur.execute("SELECT restaurant_id FROM restaurants"); rests = [r["restaurant_id"] for r in cur.fetchall()]
    menu = {}
    cur.execute("SELECT item_id, restaurant_id FROM menu_items")
    for r in cur.fetchall(): menu.setdefault(r["restaurant_id"], []).append(r["item_id"])
    addrs = {}
    cur.execute("SELECT address_id, customer_id FROM addresses")
    for r in cur.fetchall(): addrs.setdefault(r["customer_id"], []).append(r["address_id"])
    coupons = ["WELCOME20", "FEAST15", "BIRYANI10", "FLAT50", None, None, None, None]
    methods = ["UPI", "UPI", "CARD", "WALLET", "COD", "COD"]
    now = datetime.now().replace(microsecond=0)
    comments = {5: ["Loved it!", "Fresh and hot, great packaging", "Best in the area", None],
                4: ["Tasty, slightly late", "Good value", None],
                3: ["Average, okay for the price", None],
                2: ["Cold when it arrived", "Too salty"],
                1: ["Wrong item delivered", "Very late"]}
    made = 0
    for i in range(n_orders):
        cust = random.choice(customers); rest = random.choice(rests)
        cur.execute("CALL sp_place_order(%s,%s,%s,%s,@oid)", (cust, rest, random.choice(addrs[cust]), random.choice(coupons)))
        cur.execute("SELECT @oid AS oid"); oid = cur.fetchone()["oid"]
        for it in random.sample(menu[rest], random.randint(1, min(4, len(menu[rest])))):
            cur.execute("CALL sp_add_item(%s,%s,%s)", (oid, it, random.randint(1, 3)))
        cur.execute("CALL sp_checkout(%s,%s)", (oid, random.choice(methods)))
        roll = random.random()
        steps = ["preparing", "out_for_delivery", "delivered"]
        if roll < 0.06: steps = ["cancelled"]
        elif roll < 0.10: steps = ["preparing", "cancelled"]
        elif roll < 0.12: steps = []
        elif roll < 0.14: steps = ["preparing"]
        elif roll < 0.16: steps = ["preparing", "out_for_delivery"]
        for s in steps: cur.execute("CALL sp_update_status(%s,%s)", (oid, s))
        final = steps[-1] if steps else "placed"
        live = final in ("placed", "preparing", "out_for_delivery")
        placed = now - timedelta(minutes=random.randint(2, 25)) if live else \
                 now - timedelta(days=random.randint(0, 60), hours=random.randint(0, 11), minutes=random.randint(0, 59))
        dtime = placed + timedelta(minutes=random.randint(25, 70)) if final == "delivered" else None
        cur.execute("UPDATE orders SET order_time=%s, delivered_time=%s WHERE order_id=%s", (placed, dtime, oid))
        offs = {"placed": 0, "preparing": 4, "out_for_delivery": 18, "delivered": None, "cancelled": 6}
        cur.execute("SELECT log_id, new_status FROM order_status_log WHERE order_id=%s", (oid,))
        for row in cur.fetchall():
            t = dtime if row["new_status"] == "delivered" else placed + timedelta(minutes=offs[row["new_status"]])
            cur.execute("UPDATE order_status_log SET changed_at=%s WHERE log_id=%s", (t, row["log_id"]))
        if final == "delivered":
            cur.execute("UPDATE payments SET paid_at = IF(status='paid', %s, paid_at) WHERE order_id=%s AND method<>'COD'", (placed, oid))
            if random.random() < 0.72:
                rating = random.choices([5, 4, 3, 2, 1], weights=[38, 34, 14, 9, 5])[0]
                cur.execute("INSERT INTO reviews (order_id, customer_id, restaurant_id, rating, comment, created_at) VALUES (%s,%s,%s,%s,%s,%s)",
                            (oid, cust, rest, rating, random.choice(comments[rating]), dtime + timedelta(hours=random.randint(1, 20))))
        con.commit(); made += 1
    con.close()
    return made

if __name__ == "__main__":
    print("Building schema, procedures, triggers, views and master data ...")
    build_schema()
    if "--no-orders" not in sys.argv:
        print("Generating sample orders through stored procedures ...")
        print(f"  {generate_orders()} orders created")
    print("Done. Database:", DB_NAME)
