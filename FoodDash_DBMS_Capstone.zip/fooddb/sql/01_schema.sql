-- =====================================================================
--  Online Food Ordering & Delivery Database  (MySQL 8+)
--  01_schema.sql : tables, keys, constraints, indexes   (3NF)
-- =====================================================================
DROP DATABASE IF EXISTS food_delivery;
CREATE DATABASE food_delivery CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE food_delivery;

CREATE TABLE customers (
    customer_id  INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(80)  NOT NULL,
    email        VARCHAR(120) NOT NULL UNIQUE,
    phone        CHAR(10)     NOT NULL UNIQUE,
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_customer_phone CHECK (phone REGEXP '^[6-9][0-9]{9}$'),
    CONSTRAINT chk_customer_email CHECK (email LIKE '%_@_%._%')
) ENGINE=InnoDB;

CREATE TABLE addresses (
    address_id   INT AUTO_INCREMENT PRIMARY KEY,
    customer_id  INT          NOT NULL,
    label        VARCHAR(20)  NOT NULL DEFAULT 'Home',
    line1        VARCHAR(150) NOT NULL,
    city         VARCHAR(50)  NOT NULL,
    pincode      CHAR(6)      NOT NULL,
    is_default   BOOLEAN      NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_addr_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE,
    CONSTRAINT chk_pincode CHECK (pincode REGEXP '^[0-9]{6}$')
) ENGINE=InnoDB;

CREATE TABLE restaurants (
    restaurant_id INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    cuisine       VARCHAR(40)  NOT NULL,
    city          VARCHAR(50)  NOT NULL,
    is_open       BOOLEAN      NOT NULL DEFAULT TRUE,
    -- controlled denormalisation: maintained ONLY by triggers on reviews
    avg_rating    DECIMAL(3,2) NOT NULL DEFAULT 0.00,
    review_count  INT          NOT NULL DEFAULT 0,
    UNIQUE KEY uq_restaurant (name, city)
) ENGINE=InnoDB;

CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(40) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE menu_items (
    item_id       INT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT           NOT NULL,
    category_id   INT           NOT NULL,
    name          VARCHAR(100)  NOT NULL,
    price         DECIMAL(8,2)  NOT NULL,
    is_veg        BOOLEAN       NOT NULL DEFAULT TRUE,
    available     BOOLEAN       NOT NULL DEFAULT TRUE,
    UNIQUE KEY uq_item_per_restaurant (restaurant_id, name),
    CONSTRAINT fk_item_rest FOREIGN KEY (restaurant_id) REFERENCES restaurants(restaurant_id) ON DELETE CASCADE,
    CONSTRAINT fk_item_cat  FOREIGN KEY (category_id)   REFERENCES categories(category_id),
    CONSTRAINT chk_price CHECK (price > 0)
) ENGINE=InnoDB;

CREATE TABLE delivery_partners (
    partner_id  INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(80) NOT NULL,
    phone       CHAR(10)    NOT NULL UNIQUE,
    vehicle_no  VARCHAR(15) NOT NULL UNIQUE,
    status      ENUM('available','busy','offline') NOT NULL DEFAULT 'available',
    joined_on   DATE        NOT NULL DEFAULT (CURRENT_DATE)
) ENGINE=InnoDB;

CREATE TABLE coupons (
    coupon_id     INT AUTO_INCREMENT PRIMARY KEY,
    code          VARCHAR(20)  NOT NULL UNIQUE,
    discount_pct  TINYINT      NOT NULL,
    max_discount  DECIMAL(8,2) NOT NULL,
    min_order     DECIMAL(8,2) NOT NULL DEFAULT 0,
    valid_till    DATE         NOT NULL,
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    CONSTRAINT chk_pct CHECK (discount_pct BETWEEN 1 AND 90)
) ENGINE=InnoDB;

CREATE TABLE orders (
    order_id       INT AUTO_INCREMENT PRIMARY KEY,
    customer_id    INT NOT NULL,
    restaurant_id  INT NOT NULL,
    address_id     INT NOT NULL,
    partner_id     INT NULL,
    coupon_id      INT NULL,
    status         ENUM('placed','preparing','out_for_delivery','delivered','cancelled') NOT NULL DEFAULT 'placed',
    order_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delivered_time DATETIME NULL,
    subtotal       DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount       DECIMAL(10,2) NOT NULL DEFAULT 0,
    delivery_fee   DECIMAL(8,2)  NOT NULL DEFAULT 0,
    total          DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT fk_ord_cust  FOREIGN KEY (customer_id)   REFERENCES customers(customer_id),
    CONSTRAINT fk_ord_rest  FOREIGN KEY (restaurant_id) REFERENCES restaurants(restaurant_id),
    CONSTRAINT fk_ord_addr  FOREIGN KEY (address_id)    REFERENCES addresses(address_id),
    CONSTRAINT fk_ord_part  FOREIGN KEY (partner_id)    REFERENCES delivery_partners(partner_id) ON DELETE SET NULL,
    CONSTRAINT fk_ord_coup  FOREIGN KEY (coupon_id)     REFERENCES coupons(coupon_id) ON DELETE SET NULL,
    CONSTRAINT chk_amounts CHECK (subtotal >= 0 AND discount >= 0 AND delivery_fee >= 0 AND total >= 0)
) ENGINE=InnoDB;

CREATE TABLE order_items (
    order_id   INT          NOT NULL,
    item_id    INT          NOT NULL,
    quantity   INT          NOT NULL,
    unit_price DECIMAL(8,2) NOT NULL,           -- price frozen at order time (set by trigger)
    PRIMARY KEY (order_id, item_id),
    CONSTRAINT fk_oi_order FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    CONSTRAINT fk_oi_item  FOREIGN KEY (item_id)  REFERENCES menu_items(item_id),
    CONSTRAINT chk_qty CHECK (quantity BETWEEN 1 AND 20)
) ENGINE=InnoDB;

CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id   INT NOT NULL UNIQUE,              -- 1 order : 1 payment
    method     ENUM('UPI','CARD','WALLET','COD') NOT NULL,
    status     ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
    amount     DECIMAL(10,2) NOT NULL,
    paid_at    DATETIME NULL,
    CONSTRAINT fk_pay_order FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE reviews (
    review_id     INT AUTO_INCREMENT PRIMARY KEY,
    order_id      INT NOT NULL UNIQUE,           -- one review per order
    customer_id   INT NOT NULL,
    restaurant_id INT NOT NULL,
    rating        TINYINT NOT NULL,
    comment       VARCHAR(300) NULL,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rev_order FOREIGN KEY (order_id)      REFERENCES orders(order_id) ON DELETE CASCADE,
    CONSTRAINT fk_rev_cust  FOREIGN KEY (customer_id)   REFERENCES customers(customer_id),
    CONSTRAINT fk_rev_rest  FOREIGN KEY (restaurant_id) REFERENCES restaurants(restaurant_id),
    CONSTRAINT chk_rating CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB;

-- every status change is written here by a trigger
CREATE TABLE order_status_log (
    log_id      INT AUTO_INCREMENT PRIMARY KEY,
    order_id    INT NOT NULL,
    old_status  VARCHAR(20) NULL,
    new_status  VARCHAR(20) NOT NULL,
    changed_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_log_order FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- indexes for the most frequent access paths ----------
CREATE INDEX idx_orders_customer_time ON orders (customer_id, order_time);
CREATE INDEX idx_orders_restaurant    ON orders (restaurant_id, status);
CREATE INDEX idx_orders_status        ON orders (status);
CREATE INDEX idx_orders_partner       ON orders (partner_id);
CREATE INDEX idx_reviews_restaurant   ON reviews (restaurant_id);
CREATE INDEX idx_items_category       ON menu_items (category_id);
