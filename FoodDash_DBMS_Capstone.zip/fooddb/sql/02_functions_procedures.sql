-- =====================================================================
--  02_functions_procedures.sql : business logic inside the database
-- =====================================================================
USE food_delivery;
DROP FUNCTION  IF EXISTS fn_calc_discount;
DROP PROCEDURE IF EXISTS sp_recalc_order;
DROP PROCEDURE IF EXISTS sp_place_order;
DROP PROCEDURE IF EXISTS sp_add_item;
DROP PROCEDURE IF EXISTS sp_checkout;
DROP PROCEDURE IF EXISTS sp_assign_partner;
DROP PROCEDURE IF EXISTS sp_update_status;

DELIMITER $$

-- Discount = pct% of subtotal, capped at max_discount, only if subtotal >= min_order
CREATE FUNCTION fn_calc_discount(p_subtotal DECIMAL(10,2), p_coupon_id INT)
RETURNS DECIMAL(10,2)
READS SQL DATA
BEGIN
    DECLARE v_pct INT; DECLARE v_max DECIMAL(8,2); DECLARE v_min DECIMAL(8,2);
    IF p_coupon_id IS NULL THEN RETURN 0; END IF;
    SELECT discount_pct, max_discount, min_order INTO v_pct, v_max, v_min
      FROM coupons WHERE coupon_id = p_coupon_id;
    IF v_pct IS NULL OR p_subtotal < v_min THEN RETURN 0; END IF;
    RETURN LEAST(ROUND(p_subtotal * v_pct / 100, 2), v_max);
END$$

-- Recomputes subtotal / discount / delivery fee / total of one order.
-- Business rule: delivery is free for subtotal >= 499, else Rs 40.
CREATE PROCEDURE sp_recalc_order(IN p_order_id INT)
BEGIN
    DECLARE v_sub DECIMAL(10,2); DECLARE v_coupon INT; DECLARE v_disc DECIMAL(10,2); DECLARE v_fee DECIMAL(8,2);
    SELECT COALESCE(SUM(quantity * unit_price), 0) INTO v_sub FROM order_items WHERE order_id = p_order_id;
    SELECT coupon_id INTO v_coupon FROM orders WHERE order_id = p_order_id;
    SET v_disc = fn_calc_discount(v_sub, v_coupon);
    SET v_fee  = CASE WHEN v_sub = 0 THEN 0 WHEN v_sub >= 499 THEN 0 ELSE 40 END;
    UPDATE orders SET subtotal = v_sub, discount = v_disc, delivery_fee = v_fee,
                      total = v_sub - v_disc + v_fee
     WHERE order_id = p_order_id;
END$$

-- Creates an empty order after validating customer, address, restaurant and coupon.
CREATE PROCEDURE sp_place_order(IN p_customer INT, IN p_restaurant INT, IN p_address INT,
                                IN p_coupon_code VARCHAR(20), OUT p_order_id INT)
BEGIN
    DECLARE v_coupon INT DEFAULT NULL; DECLARE v_open BOOLEAN;
    IF NOT EXISTS (SELECT 1 FROM addresses WHERE address_id = p_address AND customer_id = p_customer) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Address does not belong to this customer';
    END IF;
    SELECT is_open INTO v_open FROM restaurants WHERE restaurant_id = p_restaurant;
    IF v_open IS NULL OR v_open = FALSE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Restaurant is closed or does not exist';
    END IF;
    IF p_coupon_code IS NOT NULL AND p_coupon_code <> '' THEN
        SELECT coupon_id INTO v_coupon FROM coupons
         WHERE code = UPPER(p_coupon_code) AND is_active = TRUE AND valid_till >= CURRENT_DATE;
        IF v_coupon IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid or expired coupon code';
        END IF;
    END IF;
    INSERT INTO orders (customer_id, restaurant_id, address_id, coupon_id)
    VALUES (p_customer, p_restaurant, p_address, v_coupon);
    SET p_order_id = LAST_INSERT_ID();
END$$

-- Adds an item (or increases its quantity). The BEFORE INSERT trigger validates & freezes the price.
CREATE PROCEDURE sp_add_item(IN p_order_id INT, IN p_item_id INT, IN p_qty INT)
BEGIN
    DECLARE v_status VARCHAR(20);
    SELECT status INTO v_status FROM orders WHERE order_id = p_order_id;
    IF v_status IS NULL OR v_status <> 'placed' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Items can only be added to a freshly placed order';
    END IF;
    INSERT INTO order_items (order_id, item_id, quantity, unit_price) VALUES (p_order_id, p_item_id, p_qty, 0)
    ON DUPLICATE KEY UPDATE quantity = LEAST(quantity + p_qty, 20);
    CALL sp_recalc_order(p_order_id);
END$$

-- Chooses the least-busy available partner. SKIP LOCKED lets two concurrent orders
-- pick different partners instead of waiting on (or double-booking) the same row.
CREATE PROCEDURE sp_assign_partner(IN p_order_id INT)
BEGIN
    DECLARE v_partner INT DEFAULT NULL;
    SELECT dp.partner_id INTO v_partner
      FROM delivery_partners dp
      LEFT JOIN orders o ON o.partner_id = dp.partner_id AND o.status = 'delivered'
     WHERE dp.status = 'available'
     GROUP BY dp.partner_id
     ORDER BY COUNT(o.order_id) ASC, dp.partner_id ASC
     LIMIT 1 FOR UPDATE SKIP LOCKED;
    IF v_partner IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No delivery partner is available right now';
    END IF;
    UPDATE orders SET partner_id = v_partner WHERE order_id = p_order_id;
END$$

-- Creates the payment row. Online methods are paid immediately, COD stays pending until delivery.
CREATE PROCEDURE sp_checkout(IN p_order_id INT, IN p_method VARCHAR(10))
BEGIN
    DECLARE v_total DECIMAL(10,2);
    SELECT total INTO v_total FROM orders WHERE order_id = p_order_id;
    IF v_total IS NULL OR v_total <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot check out an empty order';
    END IF;
    INSERT INTO payments (order_id, method, status, amount, paid_at)
    VALUES (p_order_id, p_method,
            IF(p_method = 'COD', 'pending', 'paid'), v_total,
            IF(p_method = 'COD', NULL, NOW()));
END$$

-- Single entry point for moving an order through its life cycle.
CREATE PROCEDURE sp_update_status(IN p_order_id INT, IN p_new_status VARCHAR(20))
BEGIN
    DECLARE v_partner INT;
    IF p_new_status = 'out_for_delivery' THEN
        SELECT partner_id INTO v_partner FROM orders WHERE order_id = p_order_id;
        IF v_partner IS NULL THEN CALL sp_assign_partner(p_order_id); END IF;
    END IF;
    UPDATE orders SET status = p_new_status WHERE order_id = p_order_id;  -- triggers do the rest
END$$

DELIMITER ;
