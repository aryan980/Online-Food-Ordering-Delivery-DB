-- =====================================================================
--  04_views.sql : reusable read models for the dashboard and reports
-- =====================================================================
USE food_delivery;

CREATE OR REPLACE VIEW v_order_summary AS
SELECT o.order_id, o.order_time, o.status, c.customer_id, c.name AS customer, r.restaurant_id, r.name AS restaurant,
       dp.name AS partner, o.subtotal, o.discount, o.delivery_fee, o.total, p.method AS payment_method, p.status AS payment_status
  FROM orders o
  JOIN customers c   ON c.customer_id   = o.customer_id
  JOIN restaurants r ON r.restaurant_id = o.restaurant_id
  LEFT JOIN delivery_partners dp ON dp.partner_id = o.partner_id
  LEFT JOIN payments p ON p.order_id = o.order_id;

CREATE OR REPLACE VIEW v_restaurant_stats AS
SELECT r.restaurant_id, r.name, r.cuisine, r.city, r.avg_rating, r.review_count,
       COUNT(o.order_id)                                   AS orders_delivered,
       COALESCE(SUM(o.total), 0)                           AS revenue,
       ROUND(COALESCE(AVG(o.total), 0), 2)                 AS avg_order_value
  FROM restaurants r
  LEFT JOIN orders o ON o.restaurant_id = r.restaurant_id AND o.status = 'delivered'
 GROUP BY r.restaurant_id, r.name, r.cuisine, r.city, r.avg_rating, r.review_count;

CREATE OR REPLACE VIEW v_item_sales AS
SELECT mi.item_id, mi.name AS item, r.restaurant_id, r.name AS restaurant, cat.name AS category,
       COALESCE(SUM(oi.quantity), 0) AS units_sold,
       COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS item_revenue
  FROM menu_items mi
  JOIN restaurants r ON r.restaurant_id = mi.restaurant_id
  JOIN categories cat ON cat.category_id = mi.category_id
  LEFT JOIN order_items oi ON oi.item_id = mi.item_id
  LEFT JOIN orders o ON o.order_id = oi.order_id AND o.status = 'delivered'
 GROUP BY mi.item_id, mi.name, r.restaurant_id, r.name, cat.name;

CREATE OR REPLACE VIEW v_partner_performance AS
SELECT dp.partner_id, dp.name, dp.status,
       COUNT(o.order_id) AS deliveries,
       ROUND(AVG(TIMESTAMPDIFF(MINUTE, o.order_time, o.delivered_time)), 1) AS avg_minutes
  FROM delivery_partners dp
  LEFT JOIN orders o ON o.partner_id = dp.partner_id AND o.status = 'delivered'
 GROUP BY dp.partner_id, dp.name, dp.status;

CREATE OR REPLACE VIEW v_customer_value AS
SELECT c.customer_id, c.name, c.email,
       COUNT(o.order_id) AS orders,
       COALESCE(SUM(o.total), 0) AS lifetime_spend,
       CASE WHEN COALESCE(SUM(o.total),0) >= 3000 THEN 'Gold'
            WHEN COALESCE(SUM(o.total),0) >= 1500 THEN 'Silver'
            WHEN COUNT(o.order_id) > 0 THEN 'Bronze' ELSE 'New' END AS tier
  FROM customers c
  LEFT JOIN orders o ON o.customer_id = c.customer_id AND o.status = 'delivered'
 GROUP BY c.customer_id, c.name, c.email;

CREATE OR REPLACE VIEW v_daily_revenue AS
SELECT DATE(order_time) AS day, COUNT(*) AS orders, SUM(total) AS revenue
  FROM orders WHERE status = 'delivered' GROUP BY DATE(order_time);
