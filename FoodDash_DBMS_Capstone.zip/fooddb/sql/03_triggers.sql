-- =====================================================================
--  03_triggers.sql : integrity rules the application can never bypass
-- =====================================================================
USE food_delivery;
DROP TRIGGER IF EXISTS trg_oi_before_insert;
DROP TRIGGER IF EXISTS trg_oi_after_insert;
DROP TRIGGER IF EXISTS trg_oi_after_update;
DROP TRIGGER IF EXISTS trg_oi_after_delete;
DROP TRIGGER IF EXISTS trg_orders_before_update;
DROP TRIGGER IF EXISTS trg_orders_after_update;
DROP TRIGGER IF EXISTS trg_orders_after_insert;
DROP TRIGGER IF EXISTS trg_pay_before_insert;
DROP TRIGGER IF EXISTS trg_rev_before_insert;
DROP TRIGGER IF EXISTS trg_rev_after_insert;
DROP TRIGGER IF EXISTS trg_rev_after_update;
DROP TRIGGER IF EXISTS trg_rev_after_delete;

DELIMITER $$

-- 1) Item must be available and from the same restaurant as the order; freeze its price.
CREATE TRIGGER trg_oi_before_insert BEFORE INSERT ON order_items FOR EACH ROW
BEGIN
    DECLARE v_price DECIMAL(8,2); DECLARE v_avail BOOLEAN; DECLARE v_item_rest INT; DECLARE v_order_rest INT;
    SELECT price, available, restaurant_id INTO v_price, v_avail, v_item_rest FROM menu_items WHERE item_id = NEW.item_id;
    SELECT restaurant_id INTO v_order_rest FROM orders WHERE order_id = NEW.order_id;
    IF v_avail = FALSE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Item is currently unavailable';
    END IF;
    IF v_item_rest <> v_order_rest THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Item belongs to a different restaurant than the order';
    END IF;
    SET NEW.unit_price = v_price;
END$$

-- 2) Keep order totals correct automatically
CREATE TRIGGER trg_oi_after_insert AFTER INSERT ON order_items FOR EACH ROW
BEGIN CALL sp_recalc_order(NEW.order_id); END$$

CREATE TRIGGER trg_oi_after_update AFTER UPDATE ON order_items FOR EACH ROW
BEGIN CALL sp_recalc_order(NEW.order_id); END$$

CREATE TRIGGER trg_oi_after_delete AFTER DELETE ON order_items FOR EACH ROW
BEGIN CALL sp_recalc_order(OLD.order_id); END$$

-- 3) Only legal status transitions: placed -> preparing -> out_for_delivery -> delivered ; cancel before dispatch
CREATE TRIGGER trg_orders_before_update BEFORE UPDATE ON orders FOR EACH ROW
BEGIN
    IF NEW.status <> OLD.status THEN
        IF NOT (
              (OLD.status = 'placed'           AND NEW.status IN ('preparing','cancelled'))
           OR (OLD.status = 'preparing'        AND NEW.status IN ('out_for_delivery','cancelled'))
           OR (OLD.status = 'out_for_delivery' AND NEW.status = 'delivered')
        ) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Illegal order status transition';
        END IF;
        IF NEW.status = 'out_for_delivery' AND NEW.partner_id IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A delivery partner must be assigned before dispatch';
        END IF;
        IF NEW.status = 'delivered' THEN SET NEW.delivered_time = NOW(); END IF;
    END IF;
END$$

-- 4) Audit log, partner availability, COD settlement, refunds
CREATE TRIGGER trg_orders_after_insert AFTER INSERT ON orders FOR EACH ROW
BEGIN
    INSERT INTO order_status_log (order_id, old_status, new_status) VALUES (NEW.order_id, NULL, NEW.status);
END$$

CREATE TRIGGER trg_orders_after_update AFTER UPDATE ON orders FOR EACH ROW
BEGIN
    IF NEW.status <> OLD.status THEN
        INSERT INTO order_status_log (order_id, old_status, new_status) VALUES (NEW.order_id, OLD.status, NEW.status);
        IF NEW.status = 'out_for_delivery' THEN
            UPDATE delivery_partners SET status = 'busy' WHERE partner_id = NEW.partner_id;
        END IF;
        IF NEW.status IN ('delivered','cancelled') AND NEW.partner_id IS NOT NULL THEN
            UPDATE delivery_partners SET status = 'available' WHERE partner_id = NEW.partner_id AND status = 'busy';
        END IF;
        IF NEW.status = 'delivered' THEN
            UPDATE payments SET status = 'paid', paid_at = NOW() WHERE order_id = NEW.order_id AND method = 'COD' AND status = 'pending';
        END IF;
        IF NEW.status = 'cancelled' THEN
            UPDATE payments SET status = IF(status = 'paid', 'refunded', 'failed') WHERE order_id = NEW.order_id;
        END IF;
    END IF;
END$$

-- 5) Payment amount must equal the order total
CREATE TRIGGER trg_pay_before_insert BEFORE INSERT ON payments FOR EACH ROW
BEGIN
    DECLARE v_total DECIMAL(10,2);
    SELECT total INTO v_total FROM orders WHERE order_id = NEW.order_id;
    IF NEW.amount <> v_total THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Payment amount does not match the order total';
    END IF;
END$$

-- 6) Only delivered orders can be reviewed, only by the customer who placed them
CREATE TRIGGER trg_rev_before_insert BEFORE INSERT ON reviews FOR EACH ROW
BEGIN
    DECLARE v_status VARCHAR(20); DECLARE v_cust INT; DECLARE v_rest INT;
    SELECT status, customer_id, restaurant_id INTO v_status, v_cust, v_rest FROM orders WHERE order_id = NEW.order_id;
    IF v_status <> 'delivered' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only delivered orders can be reviewed';
    END IF;
    IF v_cust <> NEW.customer_id THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'You can only review your own orders';
    END IF;
    SET NEW.restaurant_id = v_rest;
END$$

-- 7) Maintain restaurants.avg_rating / review_count
CREATE TRIGGER trg_rev_after_insert AFTER INSERT ON reviews FOR EACH ROW
BEGIN
    UPDATE restaurants SET avg_rating = (SELECT ROUND(AVG(rating),2) FROM reviews WHERE restaurant_id = NEW.restaurant_id),
                           review_count = (SELECT COUNT(*) FROM reviews WHERE restaurant_id = NEW.restaurant_id)
     WHERE restaurant_id = NEW.restaurant_id;
END$$

CREATE TRIGGER trg_rev_after_update AFTER UPDATE ON reviews FOR EACH ROW
BEGIN
    UPDATE restaurants SET avg_rating = (SELECT ROUND(AVG(rating),2) FROM reviews WHERE restaurant_id = NEW.restaurant_id)
     WHERE restaurant_id = NEW.restaurant_id;
END$$

CREATE TRIGGER trg_rev_after_delete AFTER DELETE ON reviews FOR EACH ROW
BEGIN
    UPDATE restaurants SET avg_rating = COALESCE((SELECT ROUND(AVG(rating),2) FROM reviews WHERE restaurant_id = OLD.restaurant_id), 0),
                           review_count = (SELECT COUNT(*) FROM reviews WHERE restaurant_id = OLD.restaurant_id)
     WHERE restaurant_id = OLD.restaurant_id;
END$$

DELIMITER ;
